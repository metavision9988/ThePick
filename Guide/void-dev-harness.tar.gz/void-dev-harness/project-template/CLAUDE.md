# CLAUDE.md — {프로젝트명}

## 프로젝트
- 정의: {한 줄 설명}
- 스택: {Frontend} / {Backend} / {DB} / {Infra}
- DEFCON: L2. 단, {L3 경로}는 L3.

## 명령어
- dev: {pnpm dev}
- build: {pnpm build}
- test: {pnpm vitest run}
- lint: {pnpm eslint . --fix}
- typecheck: {pnpm tsc --noEmit}

## 아키텍처
```
src/
  {주요 폴더 구조 — 5~10줄}
```

## Hard Limit
- {예: 서버 비용 $0}
- {예: 번들 < 200KB gzip}
- {예: 프로젝트 특화 절대 제약}

## L3 영역 (Hook이 plan 없이 수정 차단)
- {예: src/auth/}
- {예: src/payment/}

## 현재 상태
- Phase: {P1} / Epic: {E1}
- 🔓 UNLOCKED

## 벤치마크 기준선
| 메트릭 | 기준선 | 예산 |
|:---|:---|:---|
| 번들 (gzip) | {KB} | < {KB} |
| LCP | {초} | < 2.5s |

## 최근 실수 (최신 5건, 오래된 것은 삭제)
{아직 없음}

## 미해결
{아직 없음}

## 린터가 강제하는 것 (여기 반복하지 마라)
→ tsconfig strict, eslint (no-console, no-explicit-any, import-order 등)이 자동 처리
