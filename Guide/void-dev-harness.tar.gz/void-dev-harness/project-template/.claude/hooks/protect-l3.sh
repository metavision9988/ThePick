#!/bin/bash
# protect-l3.sh — L3 경로에 Write 시 plan 존재 확인
# exit 0 = 허용, exit 2 = 차단

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.filePath // empty' 2>/dev/null)

# 파일 경로가 비어있으면 허용
[ -z "$FILE_PATH" ] && exit 0

# L3 경로 패턴 (프로젝트에 맞게 수정)
L3_PATTERNS="^src/(auth|payment|crypto|billing)/"

if echo "$FILE_PATH" | grep -qE "$L3_PATTERNS"; then
  # plan 파일 존재 확인
  if [ ! -f "docs/plans/current.plan.md" ]; then
    echo "❌ L3 영역(${FILE_PATH})입니다." >&2
    echo "   docs/plans/current.plan.md를 먼저 작성하고 인간 승인을 받으세요." >&2
    echo "   → /user:void-workflow 스킬의 L3 절차를 따르세요." >&2
    exit 2
  fi
fi

exit 0
