# 개발 가이드
# 글로벌 CLAUDE.md와 중복하지 마라. 이 프로젝트 특화만 적는다.

## 코딩 규칙
- 에러 처리: catch에서 데이터 삭제 금지. 로깅 + 에러 전파 또는 폴백.
- 암묵적 전제는 assertion으로 명시:
  `assert(ctx.userId != null, 'auth context missing')`
- 외부 입력은 항상 검증 후 사용 (zod 등).

## {프레임워크} 특화
{예: Astro}
- 정적 컴포넌트: .astro 파일. runtime 상태 없음.
- 동적 컴포넌트: React Islands (client:load). 여기만 useState.
- UI 상태(Loading/Error)는 React Islands에만 적용.

{예: Cloudflare Workers}
- Workers 환경에서 Node.js API 사용 금지.
- D1 바인딩은 wrangler.toml에서 확인.
- env.DB, env.KV 등 바인딩을 통해서만 접근.

## 테스트
- 단위: vitest. 새 기능마다 테스트 최소 1개.
- E2E: Playwright. Phase 완료 시에만.
- 커버리지 목표: 80%.

## 보안 (L3 영역)
{예: src/auth/ 규칙}
- 토큰 검증은 crypto.subtle만 사용.
- 세션 무효화: 비밀번호 변경 시 기존 세션 전수 삭제.

## 배포 전 체크
- [ ] pnpm build 성공
- [ ] pnpm vitest run 통과
- [ ] 번들 크기 예산 이내
- [ ] L3 영역 변경 시 인간 검토 완료
