#!/bin/bash
# VOID DEV HARNESS — 설치 및 마이그레이션 스크립트
# 사용법:
#   새 프로젝트:    ./setup-harness.sh init /path/to/project
#   기존 마이그레이션: ./setup-harness.sh migrate /path/to/project
#   전역 설치:      ./setup-harness.sh global

set -euo pipefail

HARNESS_DIR="$(cd "$(dirname "$0")" && pwd)"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() { echo -e "${GREEN}[HARNESS]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
err() { echo -e "${RED}[ERROR]${NC} $1"; }

# ─────────────────────────────────────────────
# 1. 전역 설치 (~/.claude/)
# ─────────────────────────────────────────────
install_global() {
  log "전역 VOID DEV HARNESS 설치 시작..."
  
  CLAUDE_DIR="$HOME/.claude"
  mkdir -p "$CLAUDE_DIR"/{skills/void-workflow,commands}
  
  # CLAUDE.md 백업 + 설치
  if [ -f "$CLAUDE_DIR/CLAUDE.md" ]; then
    cp "$CLAUDE_DIR/CLAUDE.md" "$CLAUDE_DIR/CLAUDE.md.bak.$(date +%Y%m%d)"
    warn "기존 ~/.claude/CLAUDE.md → .bak으로 백업됨"
  fi
  cp "$HARNESS_DIR/global/CLAUDE.md" "$CLAUDE_DIR/CLAUDE.md"
  log "~/.claude/CLAUDE.md 설치 완료 ($(wc -l < "$CLAUDE_DIR/CLAUDE.md")줄)"
  
  # settings.json 병합 (기존 설정 보존)
  if [ -f "$CLAUDE_DIR/settings.json" ]; then
    cp "$CLAUDE_DIR/settings.json" "$CLAUDE_DIR/settings.json.bak.$(date +%Y%m%d)"
    warn "기존 settings.json → .bak으로 백업됨"
    # 기존 설정과 새 Hook을 병합 (jq가 있으면 사용, 없으면 덮어쓰기)
    if command -v jq &> /dev/null; then
      jq -s '.[0] * .[1]' "$CLAUDE_DIR/settings.json.bak."* "$HARNESS_DIR/global/settings.json" > "$CLAUDE_DIR/settings.json" 2>/dev/null || \
      cp "$HARNESS_DIR/global/settings.json" "$CLAUDE_DIR/settings.json"
    else
      cp "$HARNESS_DIR/global/settings.json" "$CLAUDE_DIR/settings.json"
    fi
  else
    cp "$HARNESS_DIR/global/settings.json" "$CLAUDE_DIR/settings.json"
  fi
  log "~/.claude/settings.json 설치 완료"
  
  # Skills & Commands
  cp "$HARNESS_DIR/global/skills/void-workflow/SKILL.md" "$CLAUDE_DIR/skills/void-workflow/SKILL.md"
  cp "$HARNESS_DIR/global/commands/verify.md" "$CLAUDE_DIR/commands/verify.md"
  cp "$HARNESS_DIR/global/commands/adr.md" "$CLAUDE_DIR/commands/adr.md"
  log "Skills + Commands 설치 완료"
  
  echo ""
  log "✅ 전역 설치 완료!"
  log "   ~/.claude/CLAUDE.md     — 불변 원칙 ($(wc -l < "$CLAUDE_DIR/CLAUDE.md")줄)"
  log "   ~/.claude/settings.json — 전역 Hook"
  log "   ~/.claude/skills/       — void-workflow"
  log "   ~/.claude/commands/     — verify, adr"
}

# ─────────────────────────────────────────────
# 2. 새 프로젝트 초기화
# ─────────────────────────────────────────────
init_project() {
  PROJECT_DIR="${1:-.}"
  PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd)"
  PROJECT_NAME="$(basename "$PROJECT_DIR")"
  
  log "프로젝트 '$PROJECT_NAME' 하네스 초기화..."
  
  mkdir -p "$PROJECT_DIR"/{.claude/{hooks,rules},docs/{plans,adr}}
  
  # CLAUDE.md (프로젝트명 치환)
  sed "s/{프로젝트명}/$PROJECT_NAME/g" "$HARNESS_DIR/project-template/CLAUDE.md" > "$PROJECT_DIR/CLAUDE.md"
  
  # settings.json
  cp "$HARNESS_DIR/project-template/.claude/settings.json" "$PROJECT_DIR/.claude/settings.json"
  
  # Hook 스크립트
  cp "$HARNESS_DIR/project-template/.claude/hooks/protect-l3.sh" "$PROJECT_DIR/.claude/hooks/protect-l3.sh"
  chmod +x "$PROJECT_DIR/.claude/hooks/protect-l3.sh"
  
  # rules/dev-guide.md
  cp "$HARNESS_DIR/project-template/.claude/rules/dev-guide.md" "$PROJECT_DIR/.claude/rules/dev-guide.md"
  
  # docs 빈 디렉토리에 .gitkeep
  touch "$PROJECT_DIR/docs/plans/.gitkeep"
  touch "$PROJECT_DIR/docs/adr/.gitkeep"
  
  echo ""
  log "✅ 프로젝트 초기화 완료!"
  log "   CLAUDE.md              — 프로젝트 지침 (편집 필요)"
  log "   .claude/settings.json  — L3 보호 Hook"
  log "   .claude/hooks/         — protect-l3.sh"
  log "   .claude/rules/         — dev-guide.md (편집 필요)"
  log ""
  warn "다음 단계:"
  warn "  1. CLAUDE.md에서 {중괄호} 부분을 프로젝트에 맞게 수정"
  warn "  2. .claude/rules/dev-guide.md에서 프레임워크/스택 규칙 수정"
  warn "  3. .claude/hooks/protect-l3.sh에서 L3 경로 패턴 수정"
}

# ─────────────────────────────────────────────
# 3. 기존 프로젝트 마이그레이션
# ─────────────────────────────────────────────
migrate_project() {
  PROJECT_DIR="${1:-.}"
  PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd)"
  PROJECT_NAME="$(basename "$PROJECT_DIR")"
  
  log "프로젝트 '$PROJECT_NAME' 마이그레이션 시작..."
  
  # 기존 파일 통계
  BEFORE_LINES=0
  BEFORE_FILES=0
  
  if [ -f "$PROJECT_DIR/CLAUDE.md" ]; then
    BEFORE_LINES=$((BEFORE_LINES + $(wc -l < "$PROJECT_DIR/CLAUDE.md")))
    BEFORE_FILES=$((BEFORE_FILES + 1))
  fi
  
  if [ -d "$PROJECT_DIR/.claude/rules" ]; then
    for f in "$PROJECT_DIR/.claude/rules"/*.md; do
      [ -f "$f" ] || continue
      BEFORE_LINES=$((BEFORE_LINES + $(wc -l < "$f")))
      BEFORE_FILES=$((BEFORE_FILES + 1))
    done
  fi
  
  # 백업
  BACKUP_DIR="$PROJECT_DIR/.claude/backup-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BACKUP_DIR"
  
  if [ -f "$PROJECT_DIR/CLAUDE.md" ]; then
    cp "$PROJECT_DIR/CLAUDE.md" "$BACKUP_DIR/CLAUDE.md.bak"
    log "CLAUDE.md → backup/"
  fi
  
  if [ -d "$PROJECT_DIR/.claude/rules" ]; then
    cp -r "$PROJECT_DIR/.claude/rules" "$BACKUP_DIR/rules.bak" 2>/dev/null || true
    log ".claude/rules/ → backup/"
  fi
  
  if [ -f "$PROJECT_DIR/.claude/settings.json" ]; then
    cp "$PROJECT_DIR/.claude/settings.json" "$BACKUP_DIR/settings.json.bak"
    log "settings.json → backup/"
  fi
  
  # 새 파일 설치
  mkdir -p "$PROJECT_DIR"/{.claude/{hooks,rules},docs/{plans,adr}}
  
  # 기존 CLAUDE.md 내용을 읽어서 핵심만 추출하는 대신,
  # 새 템플릿을 설치하고 인간이 편집하도록 안내
  sed "s/{프로젝트명}/$PROJECT_NAME/g" "$HARNESS_DIR/project-template/CLAUDE.md" > "$PROJECT_DIR/CLAUDE.md"
  
  # settings.json (기존 permissions 보존 시도)
  if [ -f "$BACKUP_DIR/settings.json.bak" ] && command -v jq &> /dev/null; then
    # 기존 permissions 보존 + 새 hooks 추가
    EXISTING_PERMS=$(jq '.permissions // {}' "$BACKUP_DIR/settings.json.bak" 2>/dev/null || echo '{}')
    jq --argjson perms "$EXISTING_PERMS" '.permissions = (.permissions * $perms)' \
      "$HARNESS_DIR/project-template/.claude/settings.json" > "$PROJECT_DIR/.claude/settings.json"
  else
    cp "$HARNESS_DIR/project-template/.claude/settings.json" "$PROJECT_DIR/.claude/settings.json"
  fi
  
  # Hook & rules
  cp "$HARNESS_DIR/project-template/.claude/hooks/protect-l3.sh" "$PROJECT_DIR/.claude/hooks/protect-l3.sh"
  chmod +x "$PROJECT_DIR/.claude/hooks/protect-l3.sh"
  
  # 기존 rules/*.md를 1개로 통합하는 대신, 새 템플릿 설치
  # 기존 rules는 backup에 보존됨
  rm -f "$PROJECT_DIR/.claude/rules"/*.md 2>/dev/null || true
  cp "$HARNESS_DIR/project-template/.claude/rules/dev-guide.md" "$PROJECT_DIR/.claude/rules/dev-guide.md"
  
  touch "$PROJECT_DIR/docs/plans/.gitkeep"
  touch "$PROJECT_DIR/docs/adr/.gitkeep"
  
  # 결과 통계
  AFTER_LINES=0
  AFTER_FILES=0
  AFTER_LINES=$((AFTER_LINES + $(wc -l < "$PROJECT_DIR/CLAUDE.md")))
  AFTER_FILES=$((AFTER_FILES + 1))
  for f in "$PROJECT_DIR/.claude/rules"/*.md; do
    [ -f "$f" ] || continue
    AFTER_LINES=$((AFTER_LINES + $(wc -l < "$f")))
    AFTER_FILES=$((AFTER_FILES + 1))
  done
  
  echo ""
  log "✅ 마이그레이션 완료!"
  echo ""
  echo "  ┌─────────┬────────┬────────┐"
  echo "  │         │  이전  │  이후  │"
  echo "  ├─────────┼────────┼────────┤"
  printf "  │ 줄 수   │ %4d줄 │ %4d줄 │\n" "$BEFORE_LINES" "$AFTER_LINES"
  printf "  │ 파일 수 │ %4d개 │ %4d개 │\n" "$BEFORE_FILES" "$AFTER_FILES"
  echo "  └─────────┴────────┴────────┘"
  echo ""
  warn "백업 위치: $BACKUP_DIR"
  warn ""
  warn "다음 단계:"
  warn "  1. $BACKUP_DIR/CLAUDE.md.bak에서 프로젝트 정보 확인"
  warn "  2. 새 CLAUDE.md에 스택/명령어/Hard Limit 채우기"
  warn "  3. .claude/rules/dev-guide.md에 프레임워크 규칙 채우기"
  warn "  4. .claude/hooks/protect-l3.sh에서 L3 경로 패턴 수정"
}

# ─────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────
case "${1:-help}" in
  global)
    install_global
    ;;
  init)
    init_project "${2:-.}"
    ;;
  migrate)
    migrate_project "${2:-.}"
    ;;
  *)
    echo "VOID DEV HARNESS Setup"
    echo ""
    echo "사용법:"
    echo "  $0 global              전역 설치 (~/.claude/)"
    echo "  $0 init [경로]         새 프로젝트 초기화"
    echo "  $0 migrate [경로]      기존 프로젝트 마이그레이션"
    echo ""
    echo "권장 순서:"
    echo "  1. $0 global           ← 먼저 (1회만)"
    echo "  2. $0 init ./my-app    ← 새 프로젝트마다"
    echo "  3. $0 migrate ./old-app ← 기존 프로젝트"
    ;;
esac
